﻿using InsuranceMiniProject.DataAccess;
using InsuranceMiniProject.DataAccess.Models;
using InsuranceMiniProject.DataAccess.Repository;
using InsuranceMiniProject.DataAccess.Repository.IRepository;
using InsuranceMiniProject.Services;
using InsuranceMiniProject.Services.Interface;
using InsuranceMiniProject.Services.Service;
using InsuranceMiniProject.UI;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Net.WebSockets;

namespace InsuranceMiniProject
{


    public class Program
    {
        //private readonly IUserService _userService;

        //public Program()
        //{
        //    _userService = new UserService();
        //}
        static void Main(string[] args)
        {
            var _serviceProvider = new ServiceCollection()
                .AddDbContext<InsuranceDbContext>()
                .AddSingleton<IUserService, UserService>()
                .AddSingleton<IUserRepository, UserRepository>()
                .AddSingleton<IPolicyService, PolicyService>()
                .AddSingleton<IPolicyRepository, PolicyRepository>()
                .BuildServiceProvider();
            var myService = _serviceProvider.GetRequiredService<IUserService>();
            var policyService = _serviceProvider.GetRequiredService<IPolicyService>();
            var userMenu = new UserMenu(policyService);

            //using (var dbContext = new InsuranceDbContext())
            //{
            //    var policies = dbContext.Policies.ToList();

            //    Console.WriteLine("Policies:");
            //    foreach (var policy in policies)
            //    {
            //        Console.WriteLine($"ID: {policy.Id}");
            //        Console.WriteLine($"Policy Number: {policy.PolicyNumber}");
            //        Console.WriteLine($"Coverage Type: {policy.CoverageType ?? "N/A"}");
            //        Console.WriteLine($"Duration: {policy.Duration ?? 0} months");
            //        Console.WriteLine($"Description: {policy.Description ?? "N/A"}");
            //        Console.WriteLine($"Installment: {policy.Installment ?? 0:C}");
            //        Console.WriteLine($"Premium Amount: {policy.PremiumAmount ?? 0:C}");
            //        Console.WriteLine($"Is Active: {policy.IsActive ?? false}");
            //        Console.WriteLine();
            //    }
            //}


            while (true)
            {
                Console.WriteLine("Welcome to Insurance Claims Management Platform!");
                Console.WriteLine("1. Register");
                Console.WriteLine("2. Login");
                Console.WriteLine("3. Exit");
                Console.Write("Enter your choice: ");
                int choice;
                if (!int.TryParse(Console.ReadLine(), out choice))
                {
                    Console.WriteLine("Invalid choice. Please try again.");
                    continue;
                }

                switch (choice)
                {
                    case 1:
                        AuthenticationMenu.Register(myService);
                        break;
                    case 2:
                        AuthenticationMenu.Login(myService);
                        break;
                    case 3:
                        Console.WriteLine("Exiting application...");
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }

        

        
    }
}


