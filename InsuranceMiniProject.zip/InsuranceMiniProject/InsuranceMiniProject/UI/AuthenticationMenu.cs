﻿using InsuranceMiniProject.DataAccess.Enum;
using InsuranceMiniProject.DataAccess.Models;
using InsuranceMiniProject.Services;
using InsuranceMiniProject.Services.Interface;
using InsuranceMiniProject.Services.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using static System.Collections.Specialized.BitVector32;

namespace InsuranceMiniProject.UI
{
    public class AuthenticationMenu
    {
        private readonly IAuditLogService _auditLogService;
        public AuthenticationMenu(IAuditLogService auditLogService)
        {

            _auditLogService = auditLogService;
            
        }

        static string ReadPassword()
        {
            var pass = string.Empty;
            ConsoleKey key;
            do
            {
                var keyInfo = Console.ReadKey(intercept: true);
                key = keyInfo.Key;

                if (key == ConsoleKey.Backspace && pass.Length > 0)
                {
                    Console.Write("\b \b");
                    pass = pass[0..^1];
                }
    
                else if (!char.IsControl(keyInfo.KeyChar))
                {
                    Console.Write("*");
                    pass += keyInfo.KeyChar;
                }
            } while (key != ConsoleKey.Enter);
            Console.WriteLine();
            return pass;
        }

        public void Register(IUserService userService)
        {
            Console.WriteLine("┌────────────────────┐");
            Console.WriteLine("│      Register      │");
            Console.WriteLine("├────────────────────┤");
            Console.WriteLine("│  1   Admin         │");
            Console.WriteLine("│  2   Agent         │");
            Console.WriteLine("│  3   User          │");
            Console.WriteLine("└────────────────────┘");
            Console.Write("Enter role number: ");
            int roleId;
            if (!int.TryParse(Console.ReadLine(), out roleId) || roleId < 1 || roleId > 3)
            {
                Console.WriteLine("Invalid role number. Please try again.");
                return;
            }

            Console.Write("Enter first name: ");
            string firstName = Console.ReadLine();
            Console.Write("Enter last name: ");
            string lastName = Console.ReadLine();
            Console.Write("Enter username: ");
            string username = Console.ReadLine();
            Console.Write("Enter password: ");
            string password = Console.ReadLine();
            Console.Write("Enter email: ");
            string email = Console.ReadLine();
            Console.Write("Enter phone number: ");
            string phoneNumber = Console.ReadLine();

            userService.RegisterUser(firstName, lastName, username, password, email, phoneNumber, roleId);

        }

        public void Login(IUserService userService)
        {
            Console.WriteLine("┌────────────────────┐");
            Console.WriteLine("│      Login:        │");
            Console.WriteLine("├────────────────────┤");
            Console.WriteLine("│  1   Admin         │");
            Console.WriteLine("│  2   Agent         │");
            Console.WriteLine("│  3   User          │");
            Console.WriteLine("└────────────────────┘");
            Console.Write("Select role: ");
            int roleId;
            if (!int.TryParse(Console.ReadLine(), out roleId) || roleId < 1 || roleId > 3)
            {
                Console.WriteLine("Invalid role number. Please try again.");
                return;
            }

            Console.Write("Enter username: ");
            string username = Console.ReadLine();
            Console.Write("Enter password: ");
            string password = ReadPassword();

            User currentUser = userService.GetUserByCredentials(username, password, roleId);

            if (currentUser != null)
            {

                if (roleId == (int)RoleEnum.Admin)
                {

                    _auditLogService.AddAuditLog(currentUser.Id, DateTime.Now, "Login", "Login Successfully", true);
                    AdminMenu.ShowMenu(currentUser);
                }
                else if (roleId == (int)RoleEnum.Agent)
                {

                    _auditLogService.AddAuditLog(currentUser.Id, DateTime.Now, "Login", "Login Successfully", true);
                    AgentMenu.ShowMenu(currentUser);
                }
                else
                {

                    _auditLogService.AddAuditLog(currentUser.Id, DateTime.Now, "Login", "Login Successfully", true);
                    UserMenu.ShowMenu(currentUser);
                }


            }
            else
            {
                Console.WriteLine("Invalid username or password.");
                _auditLogService.AddAuditLog(-1, DateTime.Now, "Login", "Login failed", false);
            }
        }

    }
}
