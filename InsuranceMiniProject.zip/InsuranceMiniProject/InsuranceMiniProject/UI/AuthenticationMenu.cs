﻿using InsuranceMiniProject.Services;
using InsuranceMiniProject.Services.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace InsuranceMiniProject.UI
{
    public class AuthenticationMenu
    {
        public static void ErrorMessage(string msg)
        {
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine(msg);
            Console.ResetColor();

        }

        // For converting password to stars
        static string ReadPassword()
        {
            var pass = string.Empty;
            ConsoleKey key;
            do
            {
                var keyInfo = Console.ReadKey(intercept: true);
                key = keyInfo.Key;

                // remove last character from password
                if (key == ConsoleKey.Backspace && pass.Length > 0)
                {
                    Console.Write("\b \b");
                    pass = pass[0..^1];
                }
                // on any key other than control characters add it to the password
                else if (!char.IsControl(keyInfo.KeyChar))
                {
                    Console.Write("*");
                    pass += keyInfo.KeyChar;
                }
            } while (key != ConsoleKey.Enter);
            Console.WriteLine();
            return pass;
        }

        public static void Register(IUserService userService)
        {
            Console.WriteLine("Registration:");
            Console.WriteLine("Select Role:");
            Console.WriteLine("1. Admin");
            Console.WriteLine("2. Agent");
            Console.WriteLine("3. User");
            Console.Write("Enter role number: ");
            int roleId;
            if (!int.TryParse(Console.ReadLine(), out roleId) || roleId < 1 || roleId > 3)
            {
                Console.WriteLine("Invalid role number. Please try again.");
                return;
            }

            Console.Write("Enter first name: ");
            string firstName = Console.ReadLine();
            Console.Write("Enter last name: ");
            string lastName = Console.ReadLine();
            Console.Write("Enter username: ");
            string username = Console.ReadLine();
            Console.Write("Enter password: ");
            string password = Console.ReadLine();
            Console.Write("Enter email: ");
            string email = Console.ReadLine();
            Console.Write("Enter phone number: ");
            string phoneNumber = Console.ReadLine();

            userService.RegisterUser(firstName, lastName, username, password, email, phoneNumber, roleId);

        }

        public static void Login(IUserService userService)
        {
            Console.WriteLine("Login:");
            Console.WriteLine("Select Role:");
            Console.WriteLine("1. Admin");
            Console.WriteLine("2. Agent");
            Console.WriteLine("3. User");
            Console.Write("Enter role number: ");
            int roleId;
            if (!int.TryParse(Console.ReadLine(), out roleId) || roleId < 1 || roleId > 3)
            {
                Console.WriteLine("Invalid role number. Please try again.");
                return;
            }

            Console.Write("Enter username: ");
            string username = Console.ReadLine();
            Console.Write("Enter password: ");
            string password = ReadPassword();

            bool isLoggedIn = userService.Login(username, password, roleId);
            if (isLoggedIn)
            {
                
                if(roleId == 1)
                {
                    AdminMenu.ShowMenu();
                }
                else if(roleId == 2)
                {
                    AgentMenu.ShowMenu();
                }
                else
                {
                    UserMenu.ShowMenu();
                }
            }
            else
            {
                Console.WriteLine("Invalid username or password.");
            }
        }
        //// Login
        //public static void Login()
        //{
        //    Console.WriteLine("\n============ Sign In ============");
        //    Console.Write("Enter UserID: ");
        //    string? userID = Console.ReadLine();

        //    Console.Write("Enter Password: ");
        //    string? password = ReadPassword();

        //    Console.WriteLine("1. Login\n2. Back to Main Menu");
        //    int option = Convert.ToInt32(Console.ReadLine());

        //    if (option == 1)
        //    {
        //        // for email validation
        //        string pattern = @"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$";

        //        // check if user id or password is empty
        //        if (string.IsNullOrEmpty(userID) || string.IsNullOrEmpty(password))
        //        {
        //            ErrorMessage("User ID or Password can't be empty");
        //        }

        //        // check if email is valid
        //        if (!Regex.IsMatch(userID, pattern))
        //        {
        //            ErrorMessage("Enter valid email");
        //        }

        //        Console.WriteLine("Login successfull");
        //    }
        //    else if (option == 2)
        //    {
        //        return;
        //    }
        //    else
        //    {
        //        Console.WriteLine("Invalid Input");
        //    }
        //}

        //// Signup
        //public static void SignUp()
        //{
        //    Console.WriteLine("\n============ Sign Up ============");
        //    Console.WriteLine("\nWant to sign Up as?");
        //    Console.WriteLine("1.Admin \n2.Agent\n3.User\n5.Back to Main Menu");
        //    Console.WriteLine("\nEnter your choice: ");
        //    int option = Convert.ToInt32(Console.ReadLine());

        //    switch (option)
        //    {
        //        case 1:
        //            Console.WriteLine("Admin");
        //            break;
        //        case 2:
        //            CustomerDetails();
        //            break;
        //        case 3:
        //            ManagerDetails();
        //            break;
        //        case 4:
        //            DriverDetails();
        //            break;
        //        case 5:
        //            return;
        //            break;
        //        default:
        //            Console.WriteLine("Invalid Input");
        //            break;
        //    }

        //}

        public static void CommonDetails()
        {

            Console.Write("Enter Name: ");
            string? name = Console.ReadLine();

            Console.Write("Enter Email: ");
            string? email = Console.ReadLine();

            Console.Write("Enter Phone Number: ");
            string? phoneNumber = Console.ReadLine();

            Console.Write("Enter Password: ");
            string? password = ReadPassword();

            Console.Write("Enter Confirm Password:");
            string? confirmPassword = ReadPassword();
        }
        public static void CustomerDetails()
        {
            CommonDetails();
            Console.Write("Enter Address: ");
            string? address = Console.ReadLine();

            //CustomerMenu customerMenu = new CustomerMenu();
            //customerMenu.ShowMenu();

        }
        public static void ManagerDetails()
        {
            CommonDetails();
            Console.Write("Enter Warehouse Name: ");
            string? warehouseName = Console.ReadLine();
        }
        public static void DriverDetails()
        {
            CommonDetails();
            Console.Write("Enter Licence Number: ");
            string? licenceNumber = Console.ReadLine();

            Console.Write("Vehicle Licence Type: ");
            string? vehicleType = Console.ReadLine();

            Console.Write("Enter Vehicle Number: ");
            string? vehicleNumber = Console.ReadLine();

        }

    }
}
