﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceMiniProject.UI
{
    public class AdminMenu
    {
        public static void ShowMenu()
        {
            Console.Clear();
            Console.WriteLine("\n<<<<<<< ADMIN MENU >>>>>>>");
            Console.WriteLine("\n1. View new admin requests.");
            Console.WriteLine("3. View new agent requests.");
            Console.WriteLine("4. View Reports");

            Console.WriteLine("4. Logout");
            Console.WriteLine("5. Exit");
            Console.WriteLine("\nEnter your choice: ");
            int choice = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Console.WriteLine("manage customers");
                    break;
                case 2:
                    Console.WriteLine("manage managers");
                    break;
                case 3:
                    Console.WriteLine("manage drivers");
                    break;
                case 4:
                    Console.WriteLine("Logout");
                    break;
                case 5:
                    return;
                    break;
                default:
                    Console.WriteLine("Invalid Choice");
                    break;

            }
        }
    }
}
