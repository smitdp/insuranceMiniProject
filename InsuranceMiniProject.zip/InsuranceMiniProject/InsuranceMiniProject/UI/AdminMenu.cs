﻿using InsuranceMiniProject.DataAccess.Models;
using InsuranceMiniProject.Services.Interface;
using InsuranceMiniProject.Services.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceMiniProject.UI
{
    public class AdminMenu
    {
        private static IUserService _userService;
        private static IAuditLogService _auditLogService;
       
        public AdminMenu(IUserService service, IAuditLogService auditLogService)
        {
                _userService = service;
            _auditLogService = auditLogService;
        }
        public static void ShowMenu(User currentUser)
        {
            Console.Clear();
            Console.WriteLine($"Welcome {currentUser.FirstName}");
           
            if(currentUser.IsApprovedByAdmin == 1)
            {

                Console.WriteLine("╔════════════════════════════════════════════════════════╗");
                Console.WriteLine("║                    ADMIN MENU                          ║");
                Console.WriteLine("╠════════════════════════════════════════════════════════╣");
                Console.WriteLine("║  1   View new admin requests.                          ║");
                Console.WriteLine("║  2   View new agent requests.                          ║");
                Console.WriteLine("║  3   View Reports                                      ║");
                Console.WriteLine("║  4   Logout                                            ║");
                Console.WriteLine("║  5   Exit                                              ║");
                Console.WriteLine("╚════════════════════════════════════════════════════════╝");

                Console.WriteLine("\nEnter your choice: ");
                int choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {

                    case 1:
                        Console.WriteLine("\n<<<<<<< NEW ADMIN REQUESTS >>>>>>>");
                       
                        var unapprovedAdmins = _userService.GetUnapprovedAdmins();

                        if (unapprovedAdmins.Count == 0)
                        {
                            Console.WriteLine("No new admin requests.");
                        }
                        else
                        {
                            foreach (var user in unapprovedAdmins)
                            {
                                Console.WriteLine($"{user.Username} - {user.FirstName} {user.LastName}");
                            }
                          
                            Console.WriteLine("Enter the username of the admin you want to manage:");
                            string Username = Console.ReadLine();


                            var selectedAdmin = unapprovedAdmins.FirstOrDefault(u => u.Username == Username);
                            if (selectedAdmin == null)
                            {
                                Console.WriteLine("User with the entered username does not exist in pending list.");
                                ShowMenu(currentUser);
                            }
                            Console.WriteLine("Choose an action: ");

                            Console.WriteLine("┌───────────────────────────────────┐");
                            Console.WriteLine("│  1   Approve                      │");
                            Console.WriteLine("│  2   Reject                       │");
                            Console.WriteLine("│  3   Defer                        │");
                            Console.WriteLine("└───────────────────────────────────┘");
                            int actionChoice = Convert.ToInt32(Console.ReadLine());
                            switch (actionChoice)
                            {
                                case 1:
                                    _userService.ProcessUserRequest(Username, 1);
                                    _auditLogService.AddAuditLog(currentUser.Id, DateTime.Now, "Approve", "Approved User", true);
                                    Console.WriteLine("Approve");
                                    break;
                                case 2:
                                   
                                    _userService.ProcessUserRequest(Username, -1);
                                    _auditLogService.AddAuditLog(currentUser.Id, DateTime.Now, "Rejected", "Rejcted User", true);
                                    Console.WriteLine("Rejected");
                                    break;
                                case 3:
                                    // Defer the action for later
                                    Console.WriteLine("Request deferred for later action.");
                                    break;
                                default:
                                    Console.WriteLine("Invalid action choice. Please try again.");
                                    break;
                            }
                        }
                        ShowMenu(currentUser);
                        break;
                    case 2:
                        var unapprovedAgents = _userService.GetUnapprovedAgents();

                        if (unapprovedAgents.Count == 0)
                        {
                            Console.WriteLine("No new agent requests.");
                        }
                        else
                        {
                            foreach (var user in unapprovedAgents)
                            {
                                Console.WriteLine($"{user.Username} - {user.FirstName} {user.LastName}");
                            }
                            // Provide options to approve, reject, or defer each request
                            Console.WriteLine("Enter the username of the admin you want to manage:");
                            string Username = Console.ReadLine();
                            var selectedAgent = unapprovedAgents.FirstOrDefault(u => u.Username == Username);
                            if (selectedAgent == null)
                            {
                                Console.WriteLine("User with the entered username does not exist in pending list.");
                                ShowMenu(currentUser);
                            }

                           
                            Console.WriteLine("Choose an action: ");
                            Console.WriteLine("┌───────────────────────────────────┐");
                            Console.WriteLine("│  1   Approve                      │");
                            Console.WriteLine("│  2   Reject                       │");
                            Console.WriteLine("│  3   Defer                        │");
                            Console.WriteLine("└───────────────────────────────────┘");
                            int actionChoice = Convert.ToInt32(Console.ReadLine());
                            switch (actionChoice)
                            {
                                case 1:
                                    Console.WriteLine("Approve");
                                    _userService.ProcessUserRequest(Username, 1);
                                    _auditLogService.AddAuditLog(currentUser.Id, DateTime.Now, "Approve", "Approved User", true);

                                    break;
                                case 2:
                                    Console.WriteLine("Reject");
                                    _userService.ProcessUserRequest(Username, -1);
                                    _auditLogService.AddAuditLog(currentUser.Id, DateTime.Now, "Reject", "Rejected User", true);
                                    break;
                                case 3:
                                    // Defer the action for later
                                    Console.WriteLine("Request deferred for later action.");
                                    break;
                                default:
                                    Console.WriteLine("Invalid action choice. Please try again.");
                                    break;
                            }
                        }
                        ShowMenu(currentUser);
                        break;
                    case 3:
                        Console.WriteLine("View Reports");
                        break;
                    case 4:
                        return;
                        break;
                    case 5:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;

                }
            }
            else if(currentUser.IsApprovedByAdmin == -1)
            {
                Console.WriteLine("You are rejected");
            } 
            else
            {
                Console.WriteLine("Request Pending");
                

            }
        }


        
    }
}



