﻿using InsuranceMiniProject.DataAccess.Models;
using InsuranceMiniProject.Services.Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceMiniProject.UI
{
    
    public class AgentMenu
    {
        private static IPolicyService _policyService;
        public AgentMenu(IPolicyService service)
        {
            _policyService = service;
        }
        public static void ShowMenu(User currentUser)
        {
            Console.Clear();
            Console.WriteLine($"Welcome {currentUser.FirstName}");
            
            if(currentUser.IsApprovedByAdmin == 1)
            {
                Console.WriteLine("╔════════════════════════════════════════════════════════╗");
                Console.WriteLine("║                     AGENT MENU                         ║");
                Console.WriteLine("╠════════════════════════════════════════════════════════╣");
                Console.WriteLine("║  1   View requests                                     ║");
                Console.WriteLine("║  2   View all policies                                 ║");
                Console.WriteLine("║  3   View user policies                                ║");
                Console.WriteLine("║  4   View Claims                                       ║");
                Console.WriteLine("║  5   View Claims history                               ║");
                Console.WriteLine("║  6   Logout                                            ║");
                Console.WriteLine("║  7   Exit                                              ║");
                Console.WriteLine("╚════════════════════════════════════════════════════════╝");

                Console.WriteLine("\nEnter your choice: ");
                int choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.WriteLine("View all requests.");
                        break;
                    case 2:
                        var policies = _policyService.GetAllPolicies();
                        Console.WriteLine("\nAll Policies:");
                        foreach (var policy in policies)
                        {
                            Console.WriteLine($"ID: {policy.Id}");
                            Console.WriteLine($"Policy Number: {policy.PolicyNumber}");
                            Console.WriteLine($"Coverage Type: {policy.CoverageType}");
                            Console.WriteLine($"Duration: {policy.Duration} months");
                            Console.WriteLine($"Description: {policy.Description}");
                            Console.WriteLine($"Installment: {policy.Installment}");
                            Console.WriteLine($"Premium Amount: {policy.PremiumAmount}");

                            Console.WriteLine();
                        }
                        break;
                    case 3:
                        Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("Invalid Choice");
                        break;

                } 
            }
            else if (currentUser.IsApprovedByAdmin == -1)
            {
                Console.WriteLine("You request has been rejected.");
            } else
            {
                Console.WriteLine("Your request has been submitted successfully. Please wait for approval");
            }
        }
    }
}
