﻿using System;
using System.Collections.Generic;

namespace InsuranceMiniProject.DataAccess.Models;

public partial class ClaimHistory
{
    public int Id { get; set; }

    public int? ClaimId { get; set; }

    public string? Action { get; set; }

    public DateTime? ActionDate { get; set; }

    public int? ActionBy { get; set; }

    public virtual User? ActionByNavigation { get; set; }

    public virtual Claim? Claim { get; set; }
}
