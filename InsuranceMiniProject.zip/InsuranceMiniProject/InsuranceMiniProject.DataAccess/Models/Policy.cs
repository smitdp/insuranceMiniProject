﻿using System;
using System.Collections.Generic;

namespace InsuranceMiniProject.DataAccess.Models;

public partial class Policy
{
    public int Id { get; set; }

    public string PolicyNumber { get; set; } = null!;

    public string PolicyName { get; set; } = null!;

    public string? CoverageType { get; set; }

    public int? Duration { get; set; }

    public string? Description { get; set; }

    public decimal? Installment { get; set; }

    public decimal? PremiumAmount { get; set; }

    public bool? IsActive { get; set; }

    public virtual ICollection<Claim> Claims { get; set; } = new List<Claim>();

    public virtual ICollection<UserPolicy> UserPolicies { get; set; } = new List<UserPolicy>();
}
