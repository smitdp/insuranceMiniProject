﻿using InsuranceMiniProject.DataAccess.Models;
using InsuranceMiniProject.DataAccess;
using InsuranceMiniProject.DataAccess.Repository.IRepository;
using InsuranceMiniProject.DataAccess.Enum;

namespace InsuranceMiniProject.DataAccess.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly InsuranceDbContext _dbContext;

        public UserRepository(InsuranceDbContext context)
        {
            _dbContext = context;
        }

        public int AddUser(User newUser)
        {
            if(_dbContext.Users.Any(u => u.Username == newUser.Username)) {
                Console.WriteLine("User name is not available");
                return 0;
            }
            if (_dbContext.Users.Any(u => u.Email == newUser.Email)) {
                Console.WriteLine("Email is already exists");
                return 0;
            }

            _dbContext.Users.Add(newUser);
            return _dbContext.SaveChanges();
            
        }

        public User GetUserByCredentials(string username, string password, int roleId)
        {
            var user = _dbContext.Users
                .FirstOrDefault(u => u.Username == username && u.Password == password && u.RoleId == roleId);

            return user;
        }


        public List<User> GetUnapprovedAdmins()
        {
            return _dbContext.Users
                .Where(u => u.RoleId == (int)RoleEnum.Admin && u.IsApprovedByAdmin == 0)
                .ToList();
        }

        public List<User> GetUnapprovedAgents()
        {
            return _dbContext.Users
                .Where(u => u.RoleId == (int)RoleEnum.Agent && u.IsApprovedByAdmin == 0)
                .ToList();
        }
        public List<User> GetApprovedAgents()
        {
            return _dbContext.Users
                .Where(u => u.RoleId == (int)RoleEnum.Agent && u.IsApprovedByAdmin == 1)
                .ToList();
        }

        public void ProcessUserRequest(string username, int action)
        {
            var admin = _dbContext.Users.FirstOrDefault(u => u.Username == username);
            if (admin != null)
            {
                admin.IsApprovedByAdmin = action; 
                _dbContext.SaveChanges(); 
            }
        }

        public void AddUserPolicy(UserPolicy userPolicy)
        {
            _dbContext.UserPolicies.Add(userPolicy);
            _dbContext.SaveChanges();
        }

        
    }
}

