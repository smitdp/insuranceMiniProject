﻿using InsuranceMiniProject.DataAccess.Models;
using InsuranceMiniProject.DataAccess;
using InsuranceMiniProject.DataAccess.Repository.IRepository;

namespace InsuranceMiniProject.DataAccess.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly InsuranceDbContext _dbContext;

        public UserRepository(InsuranceDbContext context)
        {
            _dbContext = context;
        }

        public void AddUser(User newUser)
        {
            if(_dbContext.Users.Any(u => u.Username == newUser.Username)) {
                Console.WriteLine("User name is not available");
                return;
            }
            if (_dbContext.Users.Any(u => u.Email == newUser.Email)) {
                Console.WriteLine("Email is already exists");
                return;
            }


            // Add a new user to the database
            _dbContext.Users.Add(newUser);
            _dbContext.SaveChanges();
            Console.WriteLine("User registered successfully.");
            
        }

        public bool ValidateUserCredentials(string username, string password, int roleId)
        {
            // Validate user credentials against database records
            // This might involve querying the database to check if a user with the given username and password exists
            // Additionally, you might check if the user has the specified role
            return _dbContext.Users.Any(u => u.Username == username && u.Password == password && u.RoleId == roleId);
        }
    }
}

