﻿using InsuranceMiniProject.DataAccess.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceMiniProject.DataAccess.Repository.IRepository
{
    public interface IUserRepository
    {
        int AddUser(User newUser);

        User GetUserByCredentials(string username, string password, int roleId);
       
        List<User> GetUnapprovedAdmins();

        List<User> GetUnapprovedAgents();

        List<User> GetApprovedAgents();

        void ProcessUserRequest(string username, int action);
        void AddUserPolicy(UserPolicy userPolicy);
    }
}
