﻿using InsuranceMiniProject.DataAccess.Models;
using InsuranceMiniProject.DataAccess.Repository.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceMiniProject.DataAccess.Repository
{
    public class PolicyRepository: IPolicyRepository
    {
        private readonly InsuranceDbContext _dbContext;

        public PolicyRepository(InsuranceDbContext context)
        {
            _dbContext = context;
        }


        public List<Policy> GetAllPolicies()
        {
            return _dbContext.Policies.ToList();
        }
    }
}
