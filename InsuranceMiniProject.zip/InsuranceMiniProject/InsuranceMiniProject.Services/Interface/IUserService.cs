﻿using InsuranceMiniProject.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceMiniProject.Services.Interface
{
    public interface IUserService
    {
        void RegisterUser(string firstName, string lastName, string username, string password, string email, string phoneNumber, int roleId);
        User GetUserByCredentials(string username, string password, int roleId);
        List<User> GetUnapprovedAdmins();
        List<User> GetUnapprovedAgents();
        List<User> GetApprovedAgents();
        void ProcessUserRequest(string username, int action);
        void BuyPolicy(UserPolicy userPolicy);

    }
}
