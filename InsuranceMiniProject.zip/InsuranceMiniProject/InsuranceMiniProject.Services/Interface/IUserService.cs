﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceMiniProject.Services.Interface
{
    public interface IUserService
    {
        void RegisterUser(string firstName, string lastName, string username, string password, string email, string phoneNumber, int roleId);
        bool Login(string username, string password, int roleId);

    }
}
