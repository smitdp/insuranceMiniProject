﻿using InsuranceMiniProject.DataAccess;
using InsuranceMiniProject.DataAccess.Models;
using InsuranceMiniProject.DataAccess.Repository;
using InsuranceMiniProject.DataAccess.Repository.IRepository;
using InsuranceMiniProject.Services.Interface;

namespace InsuranceMiniProject.Services.Service
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;
        private readonly IAuditLogService _auditLogService;


        public UserService(IUserRepository userRepo, IAuditLogService auditLogService)
        {
            _userRepository = userRepo;
            _auditLogService = auditLogService;
        }

        public void RegisterUser(string firstName, string lastName, string username, string password, string email, string phoneNumber, int roleId)
        {
   
            User newUser = new User
            {
                FirstName = firstName,
                LastName = lastName,
                Username = username,
                Password = password,
                Email = email,
                PhoneNumber = phoneNumber,
                RoleId = roleId,
                IsApprovedByAdmin = 0,
                IsActive = true 
            };

            int rowsAffected = _userRepository.AddUser(newUser);

            if(rowsAffected>0)
            {
                TextFormatter.Typewriter("User Registered Successfully.", ConsoleColor.Green);
                _auditLogService.AddAuditLog(newUser.Id, DateTime.Now, "Register", "Register Successfully", true);
            } else
            {
                TextFormatter.Typewriter("Registration failed.", ConsoleColor.Red);
                _auditLogService.AddAuditLog(-1, DateTime.Now, "Register", "Register Failed", false);
            }
        }

        public User GetUserByCredentials(string username, string password, int roleId)
        {

          
            return _userRepository.GetUserByCredentials(username, password, roleId);

        }
        public List<User> GetUnapprovedAdmins()
        {
            return _userRepository.GetUnapprovedAdmins();
        }



        public List<User> GetUnapprovedAgents()
        {
            return _userRepository.GetUnapprovedAgents();
        }

        public void ProcessUserRequest(string username, int action)
        {
            _userRepository.ProcessUserRequest(username, action);
        }

        public void BuyPolicy(UserPolicy userPolicy)
        {
            _userRepository.AddUserPolicy(userPolicy);
        }

        public List<User> GetApprovedAgents()
        {
            return _userRepository.GetApprovedAgents();
        }
    }
}


