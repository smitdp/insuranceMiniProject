﻿using InsuranceMiniProject.DataAccess;
using InsuranceMiniProject.DataAccess.Models;
using InsuranceMiniProject.DataAccess.Repository;
using InsuranceMiniProject.DataAccess.Repository.IRepository;
using InsuranceMiniProject.Services.Interface;

namespace InsuranceMiniProject.Services.Service
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;

        public UserService(IUserRepository userRepo)
        {
            _userRepository = userRepo;
        }

        public void RegisterUser(string firstName, string lastName, string username, string password, string email, string phoneNumber, int roleId)
        {
            // You would need to implement the logic to register a user in the database
            // This might involve creating a new User object and passing it to the UserRepository to add to the database
            User newUser = new User
            {
                FirstName = firstName,
                LastName = lastName,
                Username = username,
                Password = password,
                Email = email,
                PhoneNumber = phoneNumber,
                RoleId = roleId,
                IsApprovedByAdmin = false, // New users are not approved by default
                IsRejectedByAdmin = false,
                IsActive = true // New users are active by default
            };

            _userRepository.AddUser(newUser);
        }

        public bool Login(string username, string password, int roleId)
        {
            // You would need to implement the logic to validate user credentials and perform login
            // This might involve checking the username and password against records in the database
            // If the user credentials are valid, return true; otherwise, return false
            return _userRepository.ValidateUserCredentials(username, password, roleId);
        }
    }
}


