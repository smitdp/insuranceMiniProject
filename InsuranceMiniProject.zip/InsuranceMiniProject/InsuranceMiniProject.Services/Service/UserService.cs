﻿using InsuranceMiniProject.DataAccess;
using InsuranceMiniProject.DataAccess.Models;
using InsuranceMiniProject.DataAccess.Repository;
using InsuranceMiniProject.DataAccess.Repository.IRepository;
using InsuranceMiniProject.Services.Interface;

namespace InsuranceMiniProject.Services.Service
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;

        public UserService(IUserRepository userRepo)
        {
            _userRepository = userRepo;
        }

        public void RegisterUser(string firstName, string lastName, string username, string password, string email, string phoneNumber, int roleId)
        {
   
            User newUser = new User
            {
                FirstName = firstName,
                LastName = lastName,
                Username = username,
                Password = password,
                Email = email,
                PhoneNumber = phoneNumber,
                RoleId = roleId,
                IsApprovedByAdmin = 0,
                IsActive = true 
            };

            int rowsAffected = _userRepository.AddUser(newUser);

            if(rowsAffected>0)
            {
                TextFormatter.Typewriter("User Registered Successfully.", ConsoleColor.Green);
            } else
            {
                TextFormatter.Typewriter("Registration failed.", ConsoleColor.Red);
            }
        }

        public User GetUserByCredentials(string username, string password, int roleId)
        {
          
            return _userRepository.GetUserByCredentials(username, password, roleId);
        }
        public List<User> GetUnapprovedAdmins()
        {
            return _userRepository.GetUnapprovedAdmins();
        }



        public List<User> GetUnapprovedAgents()
        {
            return _userRepository.GetUnapprovedAgents();
        }

        public void ProcessUserRequest(string username, int action)
        {
            _userRepository.ProcessUserRequest(username, action);
        }

        public void BuyPolicy(UserPolicy userPolicy)
        {
            _userRepository.AddUserPolicy(userPolicy);
        }

        public List<User> GetApprovedAgents()
        {
            return _userRepository.GetApprovedAgents();
        }
    }
}


