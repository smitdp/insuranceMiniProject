﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceMiniProject.Services.Interface
{
    public interface IAuditLogService
    {
        void AddAuditLog(int userId, DateTime timestamp, string action, string details, bool isSuccess);
    }
}
