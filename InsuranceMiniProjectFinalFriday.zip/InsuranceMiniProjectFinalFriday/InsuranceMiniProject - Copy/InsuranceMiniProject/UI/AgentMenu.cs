﻿
using InsuranceMiniProject.Services.DTOs;
using InsuranceMiniProject.Services.Interface;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceMiniProject.UI
{
    
    public class AgentMenu
    {
        private static IPolicyService _policyService;
        private static IUserService _userService;
        public AgentMenu(IPolicyService service, IUserService userService)
        {
            _policyService = service;
            _userService = userService;
        }
        public static void ShowMenu(UserBusinessModel currentUser)
        {
            Console.Clear();
            Console.WriteLine();
            TextFormatter.CenterAlign("Welcome " + currentUser.FirstName, ConsoleColor.DarkYellow);
            Console.WriteLine();

            try
            {
                if (currentUser.IsApprovedByAdmin == 1)
                {
                    Console.ForegroundColor = ConsoleColor.DarkGray;
                    Console.WriteLine("╔════════════════════════════════════════════════════════╗");
                    Console.WriteLine("║                     AGENT MENU                         ║");
                    Console.WriteLine("╠════════════════════════════════════════════════════════╣");
                    Console.WriteLine("║  1   View assigned Policies                            ║");
                    Console.WriteLine("║  2   View all policies                                 ║");
                    Console.WriteLine("║  3   View Claims                                       ║");
                    Console.WriteLine("║  4   Logout                                            ║");
                    Console.WriteLine("║  5   Exit                                              ║");
                    Console.WriteLine("╚════════════════════════════════════════════════════════╝");
                    Console.ResetColor();
                    Console.WriteLine();
                    Console.WriteLine("\nEnter your choice: ");
                    string choice = Console.ReadLine();
                    if (!int.TryParse(choice, out int res) || res > 6 || res < 1)
                    {
                        TextFormatter.Typewriter("Invalid Choice", ConsoleColor.DarkRed);
                        Console.WriteLine();
                        Console.WriteLine("Press any key to continue . . .");

                        Console.ReadKey();
                        ShowMenu(currentUser);
                    }

                    switch (res)
                    {
                        case 1:
                            var agentPolicies = _userService.GetAgentPolicies(currentUser.Id);
                            if(agentPolicies.Count >0)
                            {
                                foreach (var policy in agentPolicies)
                                {
                                    Console.WriteLine($"{policy.UserName} | {policy.PolicyNumber} | {policy.PolicyName}");
                                }
                            } else
                            {
                                Console.WriteLine();
                                TextFormatter.Typewriter("Currently, there are no users assigned to you.", ConsoleColor.Green );
                                Console.WriteLine();
                            }
                            Console.WriteLine();
                            Console.WriteLine("Press any key to Continue . . .");
                            Console.ReadKey();
                            ShowMenu(currentUser);

                            break;
                        case 2:
                            var policies = _policyService.GetAllPolicies();
                            TextFormatter.Typewriter("\nAll Policies", ConsoleColor.DarkYellow);
                            foreach (var policy in policies)
                            {
                                Console.WriteLine($"ID: {policy.Id}");
                                Console.WriteLine($"Policy Number: {policy.PolicyNumber}");
                                Console.WriteLine($"Coverage Type: {policy.CoverageType}");
                                Console.WriteLine($"Duration: {policy.Duration} months");
                                Console.WriteLine($"Description: {policy.Description}");
                                Console.WriteLine($"Installment: {policy.Installment}");
                                Console.WriteLine($"Premium Amount: {policy.PremiumAmount}");

                                Console.WriteLine();
                            }

                            Console.WriteLine();
                            Console.WriteLine("Press any key to Continue . . .");
                            Console.ReadKey();
                            ShowMenu(currentUser); 
                            break;
                        case 3:
                            var agentClaims = _userService.GetClaimsForAgent(currentUser.Id);
                            if(agentClaims.Count > 1)
                            {
                                //foreach (var claim in agentClaims)
                                //{
                                //    Console.WriteLine($"Policy ID: {claim.PolicyId}, User ID: {claim.UserId}, Incident Date: {claim.IncidentDate}, Description: {claim.Description}, Status: {claim.Status}");
                                //}
                            }
                            else
                            {
                                TextFormatter.Typewriter("No claims available", ConsoleColor.Green);
                            }
                            Console.WriteLine();
                            Console.WriteLine("Press any key to continue . . .");
                            Console.ReadKey();
                            ShowMenu(currentUser);
                            break;
                    
                        case 4:
                            return;
                            break;
                        case 6:
                            Environment.Exit(0);
                            break;
                        default:
                            //Console.WriteLine("Invalid Choice");
                            break;

                    }
                }
                else if (currentUser.IsApprovedByAdmin == -1)
                {
                    TextFormatter.Typewriter("You request has been rejected.", ConsoleColor.Red);
                    Console.WriteLine();
                    Console.WriteLine("Press any key to continue...");
                    Console.ReadKey();
                }
                else
                {
                    TextFormatter.Typewriter("Your request has been submitted successfully. Please wait for approval", ConsoleColor.DarkGreen);
                    Console.WriteLine();
                    Console.WriteLine("Press any key to continue...");
                    Console.ReadKey();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine();
                TextFormatter.Typewriter("An error occurred : " + ex.Message);
            }
        }
    }
}
