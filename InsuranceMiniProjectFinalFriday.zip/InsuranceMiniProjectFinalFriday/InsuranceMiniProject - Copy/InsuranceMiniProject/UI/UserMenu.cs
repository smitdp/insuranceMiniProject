﻿
using InsuranceMiniProject.DataAccess.Models;
using InsuranceMiniProject.Services.DTOs;
using InsuranceMiniProject.Services.Interface;
using InsuranceMiniProject.Services.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceMiniProject.UI
{
    public class UserMenu
    {
        private static IPolicyService _policyService;
        private static IUserService _userService;
        private static IAuditLogService _auditLogService;
        public UserMenu(IPolicyService policyservice, IUserService userservice, IAuditLogService auditLogService)
        {
            _policyService = policyservice;
            _userService = userservice;
            _auditLogService = auditLogService;
        }

        //public static void ShowMenu(User currentUser)
        public static void ShowMenu(UserBusinessModel currentUser)
        {
            Console.Clear();
            Console.WriteLine();
            TextFormatter.CenterAlign("Welcome " + currentUser.FirstName + " "+ currentUser.LastName, ConsoleColor.DarkYellow);
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("╔════════════════════════════════════════════════════════╗");
            Console.WriteLine("║                      USER MENU                         ║");
            Console.WriteLine("╠════════════════════════════════════════════════════════╣");
            Console.WriteLine("║  1   View all available policies                       ║");
            Console.WriteLine("║  2   Buy Policy                                        ║");
            Console.WriteLine("║  3   View your policies                                ║");
            Console.WriteLine("║  4   Claim your policy                                 ║");
            Console.WriteLine("║  5   Logout                                            ║");
            Console.WriteLine("║  6   Exit                                              ║");
            Console.WriteLine("╚════════════════════════════════════════════════════════╝");
            Console.ResetColor();
            Console.WriteLine();
            Console.Write("\nEnter your choice: ");
            try
            {
                string choice = Console.ReadLine();
                if (!int.TryParse(choice, out int res) || res > 7 || res < 1)
                {
                    TextFormatter.Typewriter("Invalid Choice", ConsoleColor.DarkRed);
                    Console.WriteLine();
                    Console.WriteLine("Press any key to continue . . .");

                    Console.ReadKey();
                    ShowMenu(currentUser);
                }
                Console.WriteLine();

                switch (res)
                {
                    case 1:
                        var policies = _policyService.GetAllPolicies();
                        TextFormatter.Typewriter("All Policies", ConsoleColor.DarkYellow);
                        Console.WriteLine();
                        foreach (var policy in policies)
                        {
                            if (policy.IsActive == true)
                            {
                                Console.WriteLine($"Policy Number: {policy.PolicyNumber}");
                                Console.WriteLine($"Coverage Type: {policy.CoverageType}");
                                Console.WriteLine($"Duration: {policy.Duration} days");
                                Console.WriteLine($"Description: {policy.Description}");
                                Console.WriteLine($"Installment: {policy.Installment}");
                                Console.WriteLine($"Premium Amount: {policy.PremiumAmount} "); //₹
                                Console.WriteLine();
                            }
                        }
                        Console.WriteLine();
                        Console.WriteLine("Press any key to continue . . . ");
                        Console.ReadKey();
                        ShowMenu(currentUser);
                        _auditLogService.AddAuditLog(currentUser.Id, DateTime.Now, "user task", "User Viewd all policies", true);
                        break;
                    case 2:
                        TextFormatter.Typewriter("Available Policies", ConsoleColor.DarkYellow);
                        Console.WriteLine() ;
                        var availablePolicies = _policyService.GetAllPolicies();
                        foreach (var policy in availablePolicies)
                        {
                            if (policy.IsActive == true)
                            {
                                Console.Write($"Policy Number: {policy.PolicyNumber} |");
                                Console.WriteLine($"Coverage Type: {policy.CoverageType} |");
                                Console.WriteLine($"Coverage Type: {policy.CoverageType} |");
                                Console.WriteLine();

                            }
                        }

                        Console.Write("Enter policy Number:");
                        var selectedPolicyNumber = Console.ReadLine();

                        var selectedPolicy = _policyService.GetPolicyByPolicyNumber(selectedPolicyNumber);


                       if(selectedPolicy != null)
                        {
                            var todayDate = DateOnly.FromDateTime(DateTime.Today);
                            var endDate = todayDate.AddDays((int)selectedPolicy.Duration);

                            var approvedAgentList = _userService.GetApprovedAgents();
                            Random random = new Random();

                            var selectedAgent = approvedAgentList[random.Next(0, approvedAgentList.Count)];


                            UserPolicyBusinessModel userPolicy = new UserPolicyBusinessModel
                            {
                                UserId = currentUser.Id,
                                PolicyId = selectedPolicy.Id,
                                EnrollmentDate = todayDate,
                                IsActive = true,
                                EndDate = endDate,
                                AgentId = selectedAgent.Id,
                            };


                            int isSuccessfull = _userService.BuyPolicy(userPolicy);

                            if (isSuccessfull == 1)
                            {
                                Console.WriteLine();
                                TextFormatter.TypeWriterLine("Policy bought successfully!", ConsoleColor.Green);
                                Console.WriteLine();
                                _auditLogService.AddAuditLog(currentUser.Id, DateTime.Now, "user task", "User bought policy", true);
                            }
                            else
                            {
                                //TextFormatter.TypeWriterLine("Something went wrong !", ConsoleColor.DarkRed);
                            }
                            Console.WriteLine();
                            Console.WriteLine("Press any key to continue");
                            Console.ReadKey();
                            ShowMenu(currentUser);
                        } else
                        {
                            Console.WriteLine();
                            TextFormatter.Typewriter("Invalid Policy.", ConsoleColor.DarkRed);
                            Console.WriteLine("Press any key to continue . . .");
                            Console.WriteLine();
                            Console.ReadKey();
                            ShowMenu(currentUser);
                           
                        }

                        break;
                    case 3:
                        var userPolicies = _userService.GetUserPolicies(currentUser.Id);

                        if(userPolicies.Count > 0)
                        {
                            foreach (var policy in userPolicies)
                            {
                                Console.WriteLine($"{policy.PolicyName} | {policy.PolicyStartDate} | {policy.PolicyEndDate} | {policy.CoverageType} | {policy.AgentName}");
                            }
                        } else
                        {
                            TextFormatter.Typewriter("You haven't bought any policies yet.", ConsoleColor.Green);
                            TextFormatter.Typewriter("To buy a policy, please choose the 'Buy Policy' option from the menu.", ConsoleColor.Green);
                        }
                        Console.WriteLine();
                        _auditLogService.AddAuditLog(currentUser.Id, DateTime.Now, "user task", "User Viewd bought policies", true);
                        Console.WriteLine("Press any key to continue . . .");
                        Console.ReadKey();
                        ShowMenu(currentUser);
                        break;
                    case 4:
                        List<UserPolicyWithUserBusinessModel> boughtPolicies = _userService.GetUserPolicies(currentUser.Id);

                       if(boughtPolicies.Count < 1)
                        {
                            Console.WriteLine();
                            TextFormatter.Typewriter("You haven't bought any policies yet.", ConsoleColor.Green);
                            TextFormatter.Typewriter("To buy a policy, please choose the 'Buy Policy' option from the menu.", ConsoleColor.Green);
                            Console.WriteLine();

                            Console.WriteLine();
                            Console.WriteLine("Press any key to continue . . .");
                            Console.ReadKey();
                            ShowMenu(currentUser);

                        } 
                        else
                        {
                            foreach (var policy in boughtPolicies)
                            {
                                Console.WriteLine($"{policy.PolicyName} | {policy.PolicyNumber}");
                            }

                            Console.WriteLine();
                            Console.Write("Enter Policy Number to claim: ");

                            string policyNumber = Console.ReadLine();


                            var selectedPolicy1 = boughtPolicies.FirstOrDefault(policy => policy.PolicyNumber == policyNumber);

                            if(selectedPolicy1 == null)
                            {

                                TextFormatter.Typewriter("Invlalid number.", ConsoleColor.DarkRed);
                                Console.WriteLine("Press any key to Continue . . .");
                                Console.ReadKey();
                                ShowMenu(currentUser);
                            }

                            else
                            {
                                Console.Write("Enter Incident Date (YYYY-MM-DD): ");
                                string dateInput = Console.ReadLine();

                                DateOnly incidentDate;
                                if (DateOnly.TryParse(dateInput, out incidentDate))
                                {
                                    Console.Write("Add Description : ");
                                    string description = Console.ReadLine();
                                    int agentId = (int)selectedPolicy1.AgentId;

                                    int isSuccess = _userService.AddClaim(selectedPolicy1.PolicyId, currentUser.Id, incidentDate, description, agentId);

                                    if (isSuccess == 1)
                                    {
                                        TextFormatter.Typewriter("Claim submitted successfully !", ConsoleColor.Green);
                                        _auditLogService.AddAuditLog(currentUser.Id, DateTime.Now, "user task", "User submitted claim", true);
                                    }
                                    else
                                    {
                                        TextFormatter.Typewriter("Something went Wrong!", ConsoleColor.DarkRed);
                                        _auditLogService.AddAuditLog(currentUser.Id, DateTime.Now, "user task", "Claim submission failed", false);
                                    }
                                    Console.WriteLine();
                                    Console.WriteLine("Press any key to Continue . . .");
                                    Console.ReadKey();
                                    ShowMenu(currentUser);
                                }
                                else
                                {
                                    TextFormatter.Typewriter("Invalid date format. Please enter the date in YYYY-MM-DD format.", ConsoleColor.DarkRed);
                                    Console.WriteLine();
                                    Console.WriteLine("Press any key to Continue . . .");
                                    Console.ReadKey();
                                    ShowMenu(currentUser);
                                   
                                }
                            }
                            ShowMenu(currentUser);
                        }
                        break;
                    case 5:
                        _auditLogService.AddAuditLog(currentUser.Id, DateTime.Now, "Logout", "User Logout" , true);
                        return;
                        break;
                    case 6:
                        _auditLogService.AddAuditLog(currentUser.Id, DateTime.Now, "Logout", "User Logout", true);
                        Environment.Exit(0);
                        break;
                    default:
                        break;

                }
            }catch(Exception ex)
            {
                _auditLogService.AddAuditLog(-1, DateTime.Now, "Login", ex.Message + "\n" + ex.StackTrace, false);
                TextFormatter.Typewriter(ex.ToString(), ConsoleColor.DarkRed);
            }
        }
    }
}
