﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceMiniProject.DataAccess.Repository.IRepository
{
    public interface IAuditLogRepository
    {
        void AddAuditLog(int userId, DateTime timestamp, string action, string details, bool isSuccess);
    }
}
