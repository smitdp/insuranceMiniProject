﻿

namespace InsuranceMiniProject.DataAccess.Enum
{
    public enum RoleEnum
    {
        Admin = 1,
        Agent = 2,
        User = 3
    }
}
