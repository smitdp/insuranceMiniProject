﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace InsuranceMiniProject.DataAccess.Models;

public partial class InsuranceDbContext : DbContext
{
    public InsuranceDbContext()
    {
    }

    public InsuranceDbContext(DbContextOptions<InsuranceDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<AuditLog> AuditLogs { get; set; }

    public virtual DbSet<Claim> Claims { get; set; }

    public virtual DbSet<ClaimHistory> ClaimHistories { get; set; }

    public virtual DbSet<Policy> Policies { get; set; }

    public virtual DbSet<Role> Roles { get; set; }

    public virtual DbSet<User> Users { get; set; }

    public virtual DbSet<UserPolicy> UserPolicies { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=SmitP-Gift\\MSSQLSERVER2019;Database=InsuranceDb;User Id=sa;Password=cybage@123456;TrustServerCertificate=true");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<AuditLog>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__AuditLog__3214EC27512F4622");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Action).HasMaxLength(100);
            entity.Property(e => e.Category).HasMaxLength(1);
            entity.Property(e => e.Timestamp).HasColumnType("datetime");

            entity.HasOne(d => d.User).WithMany(p => p.AuditLogs)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK__AuditLogs__UserI__3A81B327");
        });

        modelBuilder.Entity<Claim>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Claims__3214EC27C58ED874");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Status).HasMaxLength(50);

            entity.HasOne(d => d.Agent).WithMany(p => p.ClaimAgents)
                .HasForeignKey(d => d.AgentId)
                .HasConstraintName("FK__Claims__AgentId__37A5467C");

            entity.HasOne(d => d.Policy).WithMany(p => p.Claims)
                .HasForeignKey(d => d.PolicyId)
                .HasConstraintName("FK__Claims__PolicyId__35BCFE0A");

            entity.HasOne(d => d.User).WithMany(p => p.ClaimUsers)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK__Claims__UserId__36B12243");
        });

        modelBuilder.Entity<ClaimHistory>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__ClaimHis__3214EC27E54EEECC");

            entity.ToTable("ClaimHistory");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Action)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ActionDate).HasColumnType("datetime");

            entity.HasOne(d => d.ActionByNavigation).WithMany(p => p.ClaimHistories)
                .HasForeignKey(d => d.ActionBy)
                .HasConstraintName("FK__ClaimHist__Actio__3E52440B");

            entity.HasOne(d => d.Claim).WithMany(p => p.ClaimHistories)
                .HasForeignKey(d => d.ClaimId)
                .HasConstraintName("FK__ClaimHist__Claim__3D5E1FD2");
        });

        modelBuilder.Entity<Policy>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Policies__3214EC271CCB99A0");

            entity.HasIndex(e => e.PolicyNumber, "UQ__Policies__46DA015708D5FCCB").IsUnique();

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.CoverageType).HasMaxLength(100);
            entity.Property(e => e.Installment).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PolicyName).HasMaxLength(50);
            entity.Property(e => e.PolicyNumber).HasMaxLength(50);
            entity.Property(e => e.PremiumAmount).HasColumnType("decimal(18, 2)");
        });

        modelBuilder.Entity<Role>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Role__3214EC27AB2E2E25");

            entity.ToTable("Role");

            entity.HasIndex(e => e.RoleName, "UQ__Role__8A2B6160CA13188C").IsUnique();

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.RoleName).HasMaxLength(50);
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Users__3214EC275731C035");

            entity.HasIndex(e => e.Username, "UQ__Users__536C85E41DF8F657").IsUnique();

            entity.HasIndex(e => e.Email, "UQ__Users__A9D10534B833D818").IsUnique();

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Email).HasMaxLength(100);
            entity.Property(e => e.FirstName).HasMaxLength(50);
            entity.Property(e => e.IsApprovedByAdmin).HasDefaultValue(0);
            entity.Property(e => e.LastName).HasMaxLength(50);
            entity.Property(e => e.Password).HasMaxLength(255);
            entity.Property(e => e.PhoneNumber).HasMaxLength(20);
            entity.Property(e => e.Username).HasMaxLength(50);

            entity.HasOne(d => d.Role).WithMany(p => p.Users)
                .HasForeignKey(d => d.RoleId)
                .HasConstraintName("FK__Users__RoleId__2A4B4B5E");
        });

        modelBuilder.Entity<UserPolicy>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__UserPoli__3214EC27FA2D3415");

            entity.ToTable("UserPolicy");

            entity.HasIndex(e => new { e.UserId, e.PolicyId }, "UC_UserPolicy").IsUnique();

            entity.Property(e => e.Id).HasColumnName("ID");

            entity.HasOne(d => d.Agent).WithMany(p => p.UserPolicyAgents)
                .HasForeignKey(d => d.AgentId)
                .HasConstraintName("FK__UserPolic__Agent__31EC6D26");

            entity.HasOne(d => d.Policy).WithMany(p => p.UserPolicies)
                .HasForeignKey(d => d.PolicyId)
                .HasConstraintName("FK__UserPolic__Polic__32E0915F");

            entity.HasOne(d => d.User).WithMany(p => p.UserPolicyUsers)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK__UserPolic__UserI__30F848ED");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
