﻿using InsuranceMiniProject.DataAccess.Models;
using InsuranceMiniProject.DataAccess.Repository;
using InsuranceMiniProject.DataAccess.Repository.IRepository;
using InsuranceMiniProject.Services;
using InsuranceMiniProject.Services.Interface;
using InsuranceMiniProject.Services.Service;
using InsuranceMiniProject.UI;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Net.WebSockets;

namespace InsuranceMiniProject
{


    public class Program
    {
        static void Main(string[] args)
        {
            var _serviceProvider = new ServiceCollection()
                .AddDbContext<InsuranceDbContext>()
                .AddSingleton<IUserService, UserService>()
                .AddSingleton<IUserRepository, UserRepository>()
                .AddSingleton<IPolicyService, PolicyService>()
                .AddSingleton<IPolicyRepository, PolicyRepository>()
                .AddSingleton<IAuditLogRepository, AuditLogRepository>()
                .AddSingleton<IAuditLogService, AuditLogService>()
                .BuildServiceProvider();
            IUserService myService = _serviceProvider.GetRequiredService<IUserService>();
            IPolicyService policyService = _serviceProvider.GetRequiredService<IPolicyService>();
            IAuditLogService auditLogService = _serviceProvider.GetService<IAuditLogService>();

            UserMenu userMenu = new UserMenu(policyService, myService, auditLogService);
            AdminMenu adminMenu = new AdminMenu(myService, auditLogService);
            AuthenticationMenu authentication = new AuthenticationMenu(auditLogService);
            AgentMenu agentMenu = new AgentMenu(policyService, myService);
            


            while (true)
            {
                
                Console.WriteLine();
                TextFormatter.CenterAlign("INSURANCE CLAIM MANAGEMENT", ConsoleColor.DarkYellow);
                Console.ForegroundColor = ConsoleColor.DarkGray;
                Console.WriteLine();
                Console.WriteLine("╔══════════════════════════════════════════════════════╗");
                Console.WriteLine("║              Insurance Claims Management             ║");
                Console.WriteLine("╠═════╦════════════════════════════════════════════════╣");
                Console.WriteLine("║  1  │ Register                                       ║");
                Console.WriteLine("║  2  │ Login                                          ║");
                Console.WriteLine("║  3  │ Exit                                           ║");
                Console.WriteLine("╚═════╩════════════════════════════════════════════════╝");
                Console.ResetColor();
                Console.WriteLine();

                Console.Write("Enter your choice: ");
                int choice;
                if (!int.TryParse(Console.ReadLine(), out choice))
                {
                    TextFormatter.Typewriter("Invalid choice. Please try again.", ConsoleColor.Red);
                    continue;
                }
                switch (choice)
                {
                    case 1:
                        authentication.Register(myService);
                        break;
                    case 2:
                        authentication.Login(myService);
                        break;
                    case 3:
                        TextFormatter.Typewriter("Exiting Application . . .", ConsoleColor.Red);
                        return;
                    default:
                        TextFormatter.Typewriter("Invalid Choice. Please try again.", ConsoleColor.Red);
                        break;
                }
            }
        }
    }
}


