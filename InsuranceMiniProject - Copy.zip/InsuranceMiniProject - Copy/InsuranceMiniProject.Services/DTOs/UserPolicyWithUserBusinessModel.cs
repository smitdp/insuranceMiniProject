﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceMiniProject.Services.DTOs
{
    public class UserPolicyWithUserBusinessModel
    {
        public int PolicyId { get; set; }
        public string? PolicyName { get; set; }
        public string? PolicyNumber { get; set; }
        public string? CoverageType { get; set; }
        public string? Description { get; set; }
        public DateOnly? PolicyStartDate { get; set; }
        public DateOnly? PolicyEndDate { get; set; }
        public int? AgentId { get; set; }
        public string? AgentName { get; set; }
        public string? UserName { get; set; }
    }
}
