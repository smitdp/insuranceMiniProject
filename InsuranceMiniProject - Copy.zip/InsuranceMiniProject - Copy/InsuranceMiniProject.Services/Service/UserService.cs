﻿using InsuranceMiniProject.DataAccess;
using InsuranceMiniProject.DataAccess.BusinessModels;
using InsuranceMiniProject.DataAccess.Models;
using InsuranceMiniProject.DataAccess.Repository;
using InsuranceMiniProject.DataAccess.Repository.IRepository;
using InsuranceMiniProject.Services.DTOs;
using InsuranceMiniProject.Services.Interface;
using Microsoft.EntityFrameworkCore;

namespace InsuranceMiniProject.Services.Service
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;
        private readonly IAuditLogService _auditLogService;

        public UserService(IUserRepository userRepo, IAuditLogService auditLogService)
        {
            _userRepository = userRepo;
            _auditLogService = auditLogService;
        }

        public void RegisterUser(string firstName, string lastName, string username, string password, string email, string phoneNumber, int roleId)
        {
   
            User newUser = new User
            {
                FirstName = firstName,
                LastName = lastName,
                Username = username,
                Password = password,
                Email = email,
                PhoneNumber = phoneNumber,
                RoleId = roleId,
                IsApprovedByAdmin = 0,
                IsActive = true 
            };

            int rowsAffected = _userRepository.AddUser(newUser);

            if(rowsAffected>0)
            {
                TextFormatter.Typewriter("User Registered Successfully.", ConsoleColor.Green);
                _auditLogService.AddAuditLog(newUser.Id, DateTime.Now, "Register", "Register Successfully", true);
            } else
            {
                TextFormatter.Typewriter("Registration failed.", ConsoleColor.Red);
                _auditLogService.AddAuditLog(-1, DateTime.Now, "Register", "Register Failed", false);
            }
        }

        public UserBusinessModel GetUserByCredentials(string username, string password, int roleId)
        {
           
                User user = _userRepository.GetUserByCredentials(username, password, roleId);
                if(user != null)
                {
                    return ConvertUserToUserServiceModel(user);
                }
                else
            {
                return null;
            }
           

        }
        public List<User> GetUnapprovedAdmins()
        {
            return _userRepository.GetUnapprovedAdmins();
        }

        public List<User> GetUnapprovedAgents()
        {
            return _userRepository.GetUnapprovedAgents();
        }

        public void ProcessUserRequest(string username, int action)
        {
            _userRepository.ProcessUserRequest(username, action);
        }

        public void BuyPolicy(UserPolicyBusinessModel userPolicy)
        {
            UserPolicy user1 = ConvertUserPolicyServiceModelToUserPolicy(userPolicy);
            _userRepository.AddUserPolicy(user1);
        }

        public List<User> GetApprovedAgents()
        {
            return _userRepository.GetApprovedAgents();
        }

        public List<UserPolicyWithUserBusinessModel> GetUserPolicies(int userId)
        {
            List<UserPolicyWithUserModel> userPolicies = _userRepository.GetUserPolicies(userId);
            List<UserPolicyWithUserBusinessModel> uPolicies = new List<UserPolicyWithUserBusinessModel>();
            foreach (var item in userPolicies)
            {
                uPolicies.Add(ConvertyUserPolicyWithUserModelToUserPolicyWithUserBusinessModel(item));
            }
            return uPolicies;
        }
        public List<UserPolicyWithUserBusinessModel> GetAgentPolicies(int userId)
        {
            List<UserPolicyWithUserModel> userPolicies = _userRepository.GetAgentPolicies(userId);
            List<UserPolicyWithUserBusinessModel> uPolicies = new List<UserPolicyWithUserBusinessModel>();
            foreach (var item in userPolicies)
            {
                uPolicies.Add(ConvertyUserPolicyWithUserModelToUserPolicyWithUserBusinessModel(item));
            }
            return uPolicies;
        }
        public void AddClaim(int policyId, int userId, DateOnly incidentDate, string description, int agentId)
        {
            _userRepository.AddClaim(policyId, userId, incidentDate, description, agentId);
        }

        public List<AuditLog> GetAuditLogs()
        {
            return _userRepository.GetAuditLogs();
        }





        //------------------------------------------------------------------------------------------------
        private UserPolicyBusinessModel ConvertUserPolicyToUserPolicyServiceModel(UserPolicy userPolicy)
        {
            UserPolicyBusinessModel userPolicyServiceModel = new UserPolicyBusinessModel()
            {
                Id = userPolicy.Id,
                UserId = userPolicy.UserId,
                PolicyId = userPolicy.PolicyId,
                AgentId = userPolicy.AgentId,
                EnrollmentDate = userPolicy.EnrollmentDate,
                EndDate = userPolicy.EndDate,
                IsActive = userPolicy.IsActive,

            };
            return userPolicyServiceModel;
        }
        private UserPolicy ConvertUserPolicyServiceModelToUserPolicy(UserPolicyBusinessModel userPolicy)
        {
            UserPolicy userPolicyServiceModel = new UserPolicy()
            {
                Id = userPolicy.Id,
                UserId = userPolicy.UserId,
                PolicyId = userPolicy.PolicyId,
                AgentId = userPolicy.AgentId,
                EnrollmentDate = userPolicy.EnrollmentDate,
                EndDate = userPolicy.EndDate,
                IsActive = userPolicy.IsActive,

            };
            return userPolicyServiceModel;
        }


        //------------------------------------------------------------------------------------------------

        private UserBusinessModel ConvertUserToUserServiceModel(User user)
        {
            UserBusinessModel userServiceModel = new UserBusinessModel()
            {
                Id = user.Id,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Username = user.Username,
                Password = user.Password,
                Email = user.Email,
                PhoneNumber = user.PhoneNumber,
                RoleId = user.RoleId,
                IsApprovedByAdmin = user.IsApprovedByAdmin,
                IsActive = user.IsActive

            };
            return userServiceModel;
        }
        private User ConvertUserServiceModelToUser(UserBusinessModel user)
        {
            User userServiceModel = new User()
            {
                Id = user.Id,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Username = user.Username,
                Password = user.Password,
                Email = user.Email,
                PhoneNumber = user.PhoneNumber,
                RoleId = user.RoleId,
                IsApprovedByAdmin = user.IsApprovedByAdmin,
                IsActive = user.IsActive

            };
            return userServiceModel;
        }



        public UserPolicyWithUserModel ConvertyUserPolicyWithUserBusinessModelToUserPolicyWithUserModel(UserPolicyWithUserBusinessModel userPolicy)
        {
            return new UserPolicyWithUserModel
            {
                PolicyId = userPolicy.PolicyId,
                PolicyName = userPolicy.PolicyName,
                PolicyNumber = userPolicy.PolicyNumber,
                CoverageType = userPolicy.CoverageType,
                Description = userPolicy.Description,
                PolicyStartDate = userPolicy.PolicyStartDate,
                PolicyEndDate = userPolicy.PolicyEndDate,
                AgentId = userPolicy.AgentId,
                AgentName = userPolicy.AgentName,
                UserName = userPolicy.UserName
            };
        }

        public UserPolicyWithUserBusinessModel ConvertyUserPolicyWithUserModelToUserPolicyWithUserBusinessModel(UserPolicyWithUserModel userModel)
        {
            return new UserPolicyWithUserBusinessModel
            {
                PolicyId = userModel.PolicyId,
                PolicyName = userModel.PolicyName,
                PolicyNumber = userModel.PolicyNumber,
                CoverageType = userModel.CoverageType,
                Description = userModel.Description,
                PolicyStartDate = userModel.PolicyStartDate,
                PolicyEndDate = userModel.PolicyEndDate,
                AgentId = userModel.AgentId,
                AgentName = userModel.AgentName,
                UserName = userModel.UserName
            };
        }

    }
}


