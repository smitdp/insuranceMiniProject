﻿using InsuranceMiniProject.DataAccess;
using InsuranceMiniProject.DataAccess.Models;
using InsuranceMiniProject.DataAccess.Repository;
using InsuranceMiniProject.DataAccess;
using InsuranceMiniProject.DataAccess;
using InsuranceMiniProject.Services.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using InsuranceMiniProject.DataAccess.Repository.IRepository;
using InsuranceMiniProject.DataAccess.BusinessModels;
using InsuranceMiniProject.Services.DTOs;

namespace InsuranceMiniProject.Services.Service
{
  
    public class PolicyService : IPolicyService
    {
        private readonly IPolicyRepository _policyRepository;

        public PolicyService(IPolicyRepository policyRepository)
        {
            _policyRepository = policyRepository;
        }

        public List<Policy> GetAllPolicies()
        {
            return _policyRepository.GetAllPolicies();  
        }

        public Policy GetPolicyByPolicyNumber(string policyNumber)
        {

            return _policyRepository.GetPolicyByPolicyNumber(policyNumber);
        }
        
    }
  
}
